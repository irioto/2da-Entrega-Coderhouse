from setuptools import setup, find_packages

setup(
    name="cliente_modelo",  # Nombre del paquete
    version="0.1",  # Versión inicial
    packages=find_packages(),  # Encuentra automáticamente los paquetes (carpetas con __init__.py)
    description="Modelo de Clientes para sistema de compras",  # Breve descripción
    author="Ignacio",  # Tu nombre o apellido
    author_email="ignacioriotorto@gmail.com",  # Tu correo
    
)

